package me.alphagamer47.test.items;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class ItemManager {

    public static ItemStack wand;
    public static ItemStack aote;
    public static ItemStack shortsword;
    public static ItemStack enchantedsnowball;
    public static ItemStack stalebread;

    public static void init() {
        createWand();
        createAote();
        createShortSword();
        createEnchantedsnowball();
        createStalebread();
    }

    private static void createWand() {
        ItemStack item = new ItemStack(Material.STICK, 1);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName("§6Wand Of Truth");
        List<String> lore = new ArrayList<>();
        lore.add("§7Damage" + " §c+150");
        lore.add("§6§lLegendary Weapon");
        meta.setLore(lore);
        meta.addEnchant(Enchantment.LUCK, 1, false);
        meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
        item.setItemMeta(meta);
        wand = item;
    }

    private static void createAote() {
        ItemStack item = new ItemStack(Material.DIAMOND_SWORD, 1);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName("§9Aspect Of The End");
        List<String> lore = new ArrayList<>();
        lore.add("§7Damage:" + " §c+100");
        lore.add("§7Strength:" + " §c+100");
        lore.add("§6Item Ability: Instant Transmission" + "§e§lRIGHT CLICK");
        lore.add("§7Teleport" + " §a8 blocks" + "§7 ahead of");
        lore.add("§7you and gain" + " §a+50" + " §f✦ Speed");
        lore.add("§7for" + " §a3 seconds.");
        lore.add("§8Mana Cost" + " §350");
        lore.add("§9§lRare Sword");
        meta.setLore(lore);
        meta.addEnchant(Enchantment.LUCK, 1, false);
        meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
        item.setItemMeta(meta);
        aote = item;

        //Shaped Recipe

        ShapedRecipe sr = new ShapedRecipe(NamespacedKey.minecraft("aoterecipe"), item);
        sr.shape(" E ", " E ", " D ");
        sr.setIngredient('E', Material.ENDER_EYE);
        sr.setIngredient('D', Material.DIAMOND);
        Bukkit.getServer().addRecipe(sr);
    }


    private static void createShortSword() {
        ItemStack item = new ItemStack(Material.IRON_SWORD, 1);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName("§5Short Sword");
        List<String> lore = new ArrayList<>();
        lore.add("§7Damage" + " §+150");
        lore.add("§6Item Ability: Blood Rage" + "§e§lRIGHT CLICK");
        lore.add("§7For 5 seconds gain strength 3");
        lore.add("§7(Sword does one damage without ability)");
        lore.add("§5§lEpic Sword");
        meta.setLore(lore);
        meta.addEnchant(Enchantment.DAMAGE_ALL, 7, false);
        AttributeModifier modifier = new AttributeModifier(UUID.randomUUID(), "generic.attackSpeed", 2.0,
                AttributeModifier.Operation.ADD_NUMBER, EquipmentSlot.HAND);
        meta.addAttributeModifier(Attribute.GENERIC_ATTACK_SPEED, modifier);
        meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
        item.setItemMeta(meta);
        shortsword = item;
    }

    private static void createEnchantedsnowball() {
        ItemStack item = new ItemStack(Material.SNOWBALL, 1);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName("§aEnchanted Snow Ball");
        List<String> lore = new ArrayList<>();
        lore.add("§7Like a snowball but gives you buffs");
        lore.add("§a§lUncommon Item");
        meta.setLore(lore);
        meta.addEnchant(Enchantment.LUCK, 1, false);
        meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
        item.setItemMeta(meta);
        enchantedsnowball = item;

        ShapedRecipe sr = new ShapedRecipe(NamespacedKey.minecraft("enchantedsnowballrecipe"), item);
        sr.shape("EEE", "EAE", "EEE");
        sr.setIngredient('E', Material.SNOWBALL);
        sr.setIngredient('A', Material.GOLD_INGOT);
        Bukkit.getServer().addRecipe(sr);
    }

    private static void createStalebread() {
        ItemStack item = new ItemStack(Material.BREAD, 1);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName("§6Stale Bread");
        List<String> lore = new ArrayList<>();
        lore.add("§7Damage" + " §c+150");
        lore.add("§6§lLegendary Weapon");
        meta.setLore(lore);
        meta.addEnchant(Enchantment.DAMAGE_ALL, 5, false);
        meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
        item.setItemMeta(meta);
        stalebread = item;

        ShapedRecipe sr = new ShapedRecipe(NamespacedKey.minecraft("stalebreadrecipe"), item);
        sr.shape("EEE", "EAE", "EEE");
        sr.setIngredient('E', Material.BREAD);
        sr.setIngredient('A', Material.DIAMOND);
        Bukkit.getServer().addRecipe(sr);
    }
}