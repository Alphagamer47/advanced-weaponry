package me.alphagamer47.test.commands;

import me.alphagamer47.test.guis.SelectionScreen;
import me.alphagamer47.test.items.ItemManager;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class WeaponryCommands implements CommandExecutor {


    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("Only players can use this!");
            return true;
        }
        Player player = (Player) sender;
        if (cmd.getName().equalsIgnoreCase("givewand")){
            player.getInventory().addItem(ItemManager.wand);
        }
        if (cmd.getName().equalsIgnoreCase("giveaote")){
            player.getInventory().addItem(ItemManager.aote);
        }
        if (cmd.getName().equalsIgnoreCase("giveshortsword")){
            player.getInventory().addItem(ItemManager.shortsword);
        }
        if (cmd.getName().equalsIgnoreCase("giveeesnowball")){
            player.getInventory().addItem(ItemManager.enchantedsnowball);
        }
        if (cmd.getName().equalsIgnoreCase("givestalebread")){
            player.getInventory().addItem(ItemManager.stalebread);
        }
        if (cmd.getName().equalsIgnoreCase("awtac")){
            SelectionScreen gui = new SelectionScreen();
            player.openInventory(gui.getInventory());
            player.sendMessage(ChatColor.AQUA + "Please make a selection");
        }
        return true;
    }
}

