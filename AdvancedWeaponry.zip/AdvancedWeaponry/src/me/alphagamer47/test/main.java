package me.alphagamer47.test;

import me.alphagamer47.test.commands.WeaponryCommands;
import me.alphagamer47.test.events.WeaponEvents;
import me.alphagamer47.test.items.ItemManager;
import org.bukkit.plugin.java.JavaPlugin;

public class main extends JavaPlugin{
    @Override
        public void onEnable(){
        ItemManager.init();
        getServer().getPluginManager().registerEvents(new WeaponEvents(), this);
        getCommand("givewand").setExecutor(new WeaponryCommands());
        getCommand("giveaote").setExecutor(new WeaponryCommands());
        getCommand("giveshortsword").setExecutor(new WeaponryCommands());
        getCommand("giveesnowball").setExecutor(new WeaponryCommands());
        getCommand("givestalebread").setExecutor(new WeaponryCommands());
        getCommand("awtac").setExecutor(new WeaponryCommands());
    }


    @Override
        public void onDisable() {

    }

}

