package me.alphagamer47.test.events;


import me.alphagamer47.test.guis.SelectionScreen;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;

public class InventoryEvents implements Listener{

    @EventHandler
    public void onClick(InventoryClickEvent e){
        if (e.getClickedInventory() == null) {return;}
        if (e.getClickedInventory().getHolder() instanceof SelectionScreen){
            e.setCancelled(true);
            Player player = (Player) e.getWhoClicked();
            if (e.getCurrentItem() == null) { return; }
            if(e.getCurrentItem().getType() == Material.LIME_STAINED_GLASS_PANE){
                player.sendMessage(ChatColor.GREEN + "You selected the accept button");
                player.closeInventory();
            }
            else if (e.getSlot() == 4){
                player.sendMessage(ChatColor.AQUA + "The terms of service are here:");
            }

            else if(e.getCurrentItem().getType() == Material.RED_STAINED_GLASS_PANE){
                player.sendMessage(ChatColor.GREEN + "You did not select the accept button");
                player.closeInventory();
            }
        }
    }

}
