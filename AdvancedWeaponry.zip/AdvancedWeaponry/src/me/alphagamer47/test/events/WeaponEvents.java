package me.alphagamer47.test.events;

import me.alphagamer47.test.items.ItemManager;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.potion.PotionType;
import org.bukkit.util.Vector;

public class WeaponEvents implements Listener {

    @EventHandler
    public static void onRightClick(PlayerInteractEvent event) {
        if (event.getAction() == Action.RIGHT_CLICK_AIR) {
            if (event.getItem() != null) {
                if (event.getItem().getItemMeta().equals(ItemManager.wand.getItemMeta())) {
                    Player player = event.getPlayer();
                    player.getWorld().spawnEntity(player.getLocation(), EntityType.FIREBALL);
                    player.sendMessage("§eUsed Tnt Blast (§b100 Mana§e)");
                }
                if (event.getItem().getItemMeta().equals(ItemManager.aote.getItemMeta())) {
                    Player player = event.getPlayer();
                    Location loc = player.getLocation();
                    Vector dir = loc.getDirection();
                    dir.normalize();
                    dir.multiply(8); //5 blocks a way
                    loc.add(dir);
                    player.teleport(loc);
                    player.sendMessage("§eUsed Instant Transmission (§b50 Mana§e)");
                }
                if (event.getItem().getItemMeta().equals(ItemManager.shortsword.getItemMeta())) {
                    Player player = event.getPlayer();
                    player.addPotionEffect(new PotionEffect(PotionEffectType.INCREASE_DAMAGE, 100, 2));
                }
                if (event.getItem().getItemMeta().equals(ItemManager.enchantedsnowball.getItemMeta())) {
                    Player player = event.getPlayer();
                    player.addPotionEffect(new PotionEffect(PotionEffectType.INCREASE_DAMAGE, 50, 0));
                    player.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 50, 0));
                }
            }
        }
    }
}


